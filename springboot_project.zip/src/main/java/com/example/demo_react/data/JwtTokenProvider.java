package com.example.demo_react.data;

import java.util.List;

public class JwtTokenProvider {
    // JWT 토큰 생성 및 검증 로직
    public String createToken(String username, List<String> roles) {
        // 토큰 생성
    }

    public boolean validateToken(String token) {
        // 토큰 검증
    }

    public String getUsernameFromToken(String token) {
        // 토큰에서 사용자 이름 추출
    }
}

