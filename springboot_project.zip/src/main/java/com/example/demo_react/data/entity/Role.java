package com.example.demo_react.data.entity;

import jakarta.persistence.*;

@Entity
public class Role {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String roleName;

    @ManyToOne
    @JoinColumn(name = "user_id")
    private User user;
}
