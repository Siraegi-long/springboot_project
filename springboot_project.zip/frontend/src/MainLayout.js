import {Outlet} from "react-router-dom";
import Navigate from "./Navigate";
import {useSelector, useDispatch} from "react-redux";
import {useEffect} from "react";
import {productAdd} from "./productSlice";
import axios from "axios";

export default function MainLayout(){
    const dispatch=useDispatch();
    const pdList=useSelector(state=>state.product.pdList);

    useEffect(()=>{
        axios.get("http://localhost:8080/product-list", {timeout:5000})
            .then(response=>{
                response.data.map(t=>dispatch(productAdd(t)));
            })
            .catch(error=>{
                if (error.code === "ECONNABORTED") {
                    console.log("시간초과")
                }
                console.log(error.message)
            });

    }, []);

    return (<>
        <h1>TEST STORE</h1>
        <Navigate></Navigate>
        <Outlet></Outlet>

    </>);
}


