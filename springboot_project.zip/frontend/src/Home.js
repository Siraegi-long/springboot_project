import React from 'react';

function Home() {
    return (
        <div>
            <h1>홈페이지에 오신 것을 환영합니다!</h1>
            <p>여기는 로그인 후에 보이는 페이지입니다.</p>
        </div>
    );
}

export default Home;
